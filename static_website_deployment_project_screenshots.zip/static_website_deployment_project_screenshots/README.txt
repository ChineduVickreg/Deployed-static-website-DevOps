Deploy Static Website on AWS

In this project, you will deploy a static website to AWS using S3, CloudFront, and IAM.

And here are the three differents endpoints for s3, CloudFront and s3 with index.html


S3 endpoint
http://myproject1-811167487409-bucket.s3-website-us-east-1.amazonaws.com


cloudfront endpoint
https://d286k54ymvyjow.cloudfront.net

s3 endpoint with index.html
http://myproject1-811167487409-bucket.s3.amazonaws.com/index.html